// js/script.js
console.log("");

<script src="js/script.js" defer></script>